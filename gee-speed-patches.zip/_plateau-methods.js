  _convergedPlateau(key, meanCos, rep) {
    if (!Number.isFinite(meanCos)) return null;
    const st = (this._plateau ||= {});
    const h = (st[key] ||= { prev: null, peak: 0, flat: 0, n: 0 });
    h.n += 1;
    if (h.prev === null) { h.prev = meanCos; return null; }
    const delta = Math.abs(meanCos - h.prev);
    h.prev = meanCos;
    if (delta > h.peak) h.peak = delta;
    // NOTHING HAS MOVED AT ALL. A phase whose metric never changed has not
    // converged, it has not started - the same confusion the old test made,
    // and the reason a bare "delta is small" is not enough on its own.
    if (h.peak <= 0) return null;
    let frac = 0.10;
    try {
      const f = Number(typeof process !== 'undefined' && process.env && process.env.DREAM_PLATEAU_FRAC);
      if (Number.isFinite(f) && f > 0 && f < 1) frac = f;
    } catch { /* default */ }
    if (delta <= h.peak * frac) h.flat += 1; else h.flat = 0;
    // Two consecutive flat reps, same as the original's patience, but now
    // measured against movement instead of against a level.
    if (h.flat >= 2) {
      return { reason: 'plateau', delta, peak: h.peak, reps: h.n };
    }
    return null;
  }

  /**
   * DOSE (2026-08-23) - a phase must say how much of its budget it delivered.
   *
   * The 12.5% above was invisible for as long as it existed because the only
   * line printed was the exit itself, and nothing summed them. Any loop that
   * can stop short now reports `reps X/Y` so a shortfall shows up in the
   * ordinary log rather than needing somebody to count exits by eye.
   */
  /**
   * DOSELEDGER (2026-08-23) - A SHORT PHASE IS A CORPUS DEFECT, NOT A SKIP.
   *
   * Operator: *"she is not the standard AI, and kids don't get to skip
   * learning. NOW if it is NOT valid TO train her, fine, the job was already
   * done, but the corpus should be adjusted to fit that, not be left off."*
   *
   * That is the correct reading and it changes what an early exit MEANS. If a
   * phase declares 200 reps and genuinely reaches its fixed point at 100, the
   * defect is the declared 200. Routing around it silently leaves the corpus
   * asserting a dose that never happens, and this repo PRICES THE WALK off
   * those numbers - the re-price LAW multiplies reps by sentences to compute
   * hours, so every estimate is being made from a figure that is not real.
   *
   * So the exit still protects against genuine waste, and it now also files
   * the discrepancy as work: phase name, declared, actually needed. Fix the
   * authored number and the exit stops firing, because the declaration will be
   * true. That is the difference between a curriculum that got shorter and a
   * curriculum that was written wrong.
   *
   * The ledger is written next to the walk log so it can be read without a
   * grep, and it accumulates across a run rather than printing one line per
   * exit and hoping somebody counts them.
   */
  _recordDose(label, needed, declared) {
    const led = (this._doseLedger ||= new Map());
    const prev = led.get(label);
    // Keep the LARGEST need seen for a phase. A phase that converged at 40 once
    // and 90 another time needs 90: the authored dose has to cover the worst
    // case, not the luckiest one.
    if (!prev || needed > prev.needed) {
      led.set(label, { needed, declared, seen: (prev ? prev.seen : 0) + 1 });
    } else {
      prev.seen += 1;
    }
    // Print the ledger on a slow cadence. One line per exit is noise; the
    // TABLE is the thing somebody acts on.
    const now = Date.now();
    if (!this._doseLedgerAt || (now - this._doseLedgerAt) > 120000) {
      this._doseLedgerAt = now;
      const rows = [...led.entries()]
        .filter(([, v]) => v.needed < v.declared)
        .sort((a, b) => (a[1].needed / a[1].declared) - (b[1].needed / b[1].declared));
      if (rows.length) {
        const worst = rows.slice(0, 6)
          .map(([k, v]) => `${k} declared ${v.declared} needs ${v.needed}`)
          .join(' · ');
        this._hb(`[Curriculum] DOSE LEDGER — ${rows.length} phase(s) declare more reps than they use. Worst: ${worst}. These are CORPUS CORRECTIONS, not skips: set the authored rep count to what the phase actually needs and the early exit stops firing, because the declaration becomes true. Until then every walk estimate is priced off a dose that never happens.`);
      }
    }
  }

  _doseTag(done, declared) {
    const d = Math.max(0, done | 0), n = Math.max(1, declared | 0);
    const pct = Math.round((100 * d) / n);
    return ` · reps ${d}/${n} (${pct}% of dose)`;
  }

