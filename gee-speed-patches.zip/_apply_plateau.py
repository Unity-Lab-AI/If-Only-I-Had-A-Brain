"""Port the PLATEAU convergence fix onto Gee's current main.

Run inside the throwaway worktree checked out at origin/main. Applies by exact
string match, not line number, so it survives his file being 11,000 lines
longer than ours. Refuses loudly rather than half-applying.
"""
import sys
from pathlib import Path

TARGET = Path("js/brain/curriculum.js")
METHODS = Path(r"C:\repos\gee-speed-patches\_plateau-methods.js")

src = TARGET.read_text(encoding="utf-8")
methods = METHODS.read_text(encoding="utf-8").rstrip() + "\n"

fails = []

# ---- 1. insert the two methods at class level -----------------------------
ANCHOR = "\n  async _probePropagate(projName, srcVec) {"
if ANCHOR not in src:
    fails.append("anchor for method insertion not found (_probePropagate)")
elif "_convergedPlateau" in src:
    fails.append("_convergedPlateau already present - nothing to do")
else:
    src = src.replace(ANCHOR, "\n" + methods + ANCHOR, 1)

# ---- 2. QA-binding early exit ---------------------------------------------
OLD1 = """              this._qaConvergenceStreak = (this._qaConvergenceStreak || 0) + 1;
              if (this._qaConvergenceStreak >= 2 && rep < reps - 1) {
                this._hb(`[Curriculum][${label}] convergence early-exit at rep ${rep + 1}/${reps} \u00b7 mean-cos=${quickSep.meanCos.toFixed(3)} < 0.40`);
                break;
              }"""
NEW1 = """              // PLATEAU - convergence is the metric STOPPING, not the metric
              // being small. The streak test below fired at rep 3 EVERY time
              // (reps 1 and 2 always pass, the third always breaks), so the
              // exit point was a property of the loop shape, not of training.
              const _conv = this._convergedPlateau(`qa:${label}`, quickSep.meanCos, rep);
              if (_conv && rep < reps - 1) {
                this._hb(`[Curriculum][${label}] convergence early-exit at rep ${rep + 1}/${reps} \u00b7 mean-cos=${quickSep.meanCos.toFixed(3)} PLATEAUED (delta ${_conv.delta.toFixed(4)} <= peak ${_conv.peak.toFixed(4)} x frac)${this._doseTag(rep + 1, reps)}`);
                break;
              }"""
if OLD1 not in src:
    fails.append("QA-binding early-exit block not found verbatim")
else:
    src = src.replace(OLD1, NEW1, 1)

# ---- 3. the second early exit ---------------------------------------------
OLD2 = """            this._convergenceStreak = (this._convergenceStreak || 0) + 1;
            if (this._convergenceStreak >= 2 && rep < reps - 1) {
              this._hb(`[Curriculum][${label}] convergence early-exit at rep ${rep + 1}/${reps} \u00b7 mean-cos=${quickSep.meanCos.toFixed(3)} < ${overloadMax}`);
              break;
            }"""
NEW2 = """            // PLATEAU - see the matching change in the QA-binding exit.
            const _conv = this._convergedPlateau(`sem:${label}`, quickSep.meanCos, rep);
            if (_conv && rep < reps - 1) {
              this._hb(`[Curriculum][${label}] convergence early-exit at rep ${rep + 1}/${reps} \u00b7 mean-cos=${quickSep.meanCos.toFixed(3)} PLATEAUED (delta ${_conv.delta.toFixed(4)} <= peak ${_conv.peak.toFixed(4)} x frac)${this._doseTag(rep + 1, reps)}`);
              break;
            }"""
if OLD2 not in src:
    fails.append("second early-exit block not found verbatim")
else:
    src = src.replace(OLD2, NEW2, 1)

if fails:
    print("REFUSED - nothing written:")
    for f in fails:
        print("  " + f)
    sys.exit(1)

TARGET.write_text(src, encoding="utf-8")
print("applied: 2 methods inserted, 2 early-exit sites rewritten")
