# Three patches for gee-brain walk speed

Built 2 Sep 2026 against `origin/main` @ `35005fc4`. All three apply cleanly to
that commit, in this order, and `node --check` passes on every file they touch:

    git apply 01-phasefilter.patch
    git apply 02-precell-max.patch
    git apply 03-plateau-convergence.patch

    2 files changed, 177 insertions(+), 7 deletions(-)

Verified by applying them to a throwaway worktree checked out at his main, not
by reading them. `03` was hand-ported because our file is ~11,000 lines shorter
than his and the original patch failed on line offsets alone; the code it
replaces is byte-identical on both sides.

---

## 03-plateau-convergence.patch — the one that matters

**Both convergence early-exits stop the rep loop at rep 3, every single time,
regardless of what is being trained.**

Measured across a full 65,696-line kindergarten walk:

    473 shortfalls · 1,419 reps delivered of 11,307 declared = 12.5%
    EVERY SINGLE ONE stopped at rep 3

    ELA-K-STRUCTURE-CONCRETE-SENTENCES-HI    3 of 200    1.5%
    ELA-K-STRUCTURE-CONCRETE-SENTENCES-MID   3 of 150    2.0%
    ELA-K-STRUCTURE-QUESTION-PRODUCTION      3 of 100    3.0%

Always rep 3, because the streak needs two consecutive passes and checking
begins at `rep >= 1`: reps 1 and 2 always pass and the third always breaks. The
exit point is a property of the LOOP SHAPE, not of the training.

It fires that early because it tests whether `meanCos` is BELOW a threshold, and
it exits on values of 0.015 to 0.111. At the start of a phase the patterns have
barely been written, so two of them are near-orthogonal by default. "Well
separated" and "almost nothing has been written yet" produce the same low
cosine and the test cannot tell them apart. The `FC.3` guard was aimed at this
and is too narrow — it only catches `meanCos` AND `maxCos` both under 0.05.

The fix needs no threshold: convergence means the measurement has STOPPED
MOVING. Track `meanCos` per rep and exit when the recent change is small
RELATIVE to the largest change this phase has already produced. Early on the
deltas are large because learning is happening, so it cannot fire; when
training genuinely saturates the deltas collapse and it exits, which is what
the original exit was for.

Two new methods (`_convergedPlateau`, `_doseTag` plus a dose ledger) and the
two exit conditions rewritten to call them. Dial: `DREAM_PLATEAU_FRAC`
(default 0.10).

**This makes a walk take LONGER, not shorter.** It is here because the reps it
restores are the sentence-structure phases — the ones behind "she cannot build
a sentence" — and because a five-day walk that delivers 12.5% of its declared
dose is the most expensive kind of slow there is.

The dose ledger it adds prints which phases declare more reps than they use.
Those are corpus corrections: set the authored rep count to what the phase
actually needs and the exit stops firing, because the declaration becomes true.

## 01-phasefilter.patch — run one phase instead of the whole walk

Turns a "change one thing, walk for a day, find out" loop into a targeted run.

## 02-precell-max.patch — a diagnostic run stops paying for the whole vocabulary

`DREAM_PRECELL_MAX` caps the pre-cell vocabulary pass so a diagnostic run does
not pay full price for material it is not testing.

---

## What is deliberately NOT here

Everything else we have on this axis, he already has, and in several cases more
of it than us. Checked directly against his tree, not inferred:

    _probePropagate   ours 24   his 23     donor-first gate probes
    gateProbe         ours 18   his 25     he has MORE
    GATEGPU           ours  8   his 16     he has more
    spkCacheToken     ours  6   his  3     he has it
    FATIGUE           ours  8   his  1     he has it

He also found the per-word CPU propagate himself, four days after we did, and
wrote a measurement we never took (`LOOPCHAT.1`, 2026-08-26: *"THE CPU SHADOW
WAS A SYNCHRONOUS 1.5M→720K SPARSE PROPAGATE, ONCE PER SPOKEN WORD, ON THE
EVENT LOOP ... 29% of bound propagates refuse and drop to CPU"*).

`SERVERORGANS` and `GPUREAD` are ours alone but are correctness fixes, not
speed, and `GPUREAD` solves a problem he already solved another way. Left out
of this set on purpose.
