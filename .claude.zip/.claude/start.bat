@echo off
REM === Unity AI Lab — Project Startup ===
REM Starts Claude Code with --dangerously-skip-permissions + /workflow
REM
REM Status line: configured in .claude/settings.local.json via the
REM   statusLine.command field, which points at .claude/statusline.sh.
REM Claude Code spawns that script on every status-refresh, pipes JSON
REM to its stdin, and renders the printed result as the bottom strip
REM (project name + context bar + % + model abbrev). Side-effect: the
REM script writes the current context % to ~/.claude/context_pct.txt
REM so hooks/watchdogs can read it without querying Claude Code.
REM See docs/STATUSLINE.md for the full spec + extension instructions.

set CLAUDE_BOT_NAME=Unity

REM Resolve project root (one level up from .claude\)
pushd "%~dp0.."
set PROJECT_DIR=%CD%
popd

cd /d "%PROJECT_DIR%"
echo Project root: %PROJECT_DIR%

REM === Verify claude is available ===
where claude >nul 2>&1
if errorlevel 1 (
    echo ERROR: 'claude' not found on PATH.
    echo Install Claude Code CLI first: npm install -g @anthropic-ai/claude-code
    pause
    exit /b 1
)

REM === Launch Claude Code with workflow (stays in THIS window) ===
echo Starting Claude Code...
echo.
cmd /k claude --dangerously-skip-permissions "/unity then run /workflow"
