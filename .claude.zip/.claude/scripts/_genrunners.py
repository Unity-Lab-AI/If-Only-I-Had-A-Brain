"""Reusable per-grade new-track runner generator. Edit GRADE + SPEC, run.
Inserts runners before the runLife<GT> anchor in the grade file. CRLF-safe,
apostrophe-stripping (single-quoted JS strings)."""
import io, sys

def build(GRADE, GT, SPEC, coding_grade=None):
    p = "js/brain/curriculum/%s.js" % GRADE
    src = io.open(p, "r", encoding="utf-8", newline="").read()
    crlf = src.count("\r\n"); lf = src.count("\n") - crlf
    nl = "\r\n" if crlf >= lf else "\n"
    def L(x): return nl.join(x)
    def S(x): return x.replace("'", "")
    anchor = "  async runLife%s(ctx) {" % GT
    assert src.count(anchor) == 1, "%s anchor=%d" % (GRADE, src.count(anchor))
    cap = {'cs':'Cs','pe':'Pe','ap':'Ap'}
    def C(x): return cap.get(x, x.capitalize())
    out = ["  // ── FULL-ROSTER %s new-track runners (generated; apostrophes stripped)." % GT]
    for sub, (tag, gst, vocab, sentences, chains, samples) in SPEC.items():
        nm = "run%s%sReal" % (C(sub), GT)
        out.append("  async %s(ctx) {" % nm)
        out.append("    const VOCAB = [")
        vv = [S(w) for w in vocab]
        for i in range(0, len(vv), 8):
            out.append("      " + ", ".join("'%s'" % w for w in vv[i:i+8]) + ",")
        out += ["    ];", "    await this._teachVocabList(VOCAB, ctx, { reps: 3 });", "    const SENTENCES = ["]
        for s in sentences: out.append("      '%s'," % S(s))
        out += ["    ];", "    await this._teachSentenceList(SENTENCES, ctx, { reps: 2, ticksPerWord: 2 });", "    await this._teachCausalChains(["]
        out.append("      " + ", ".join("['%s', '%s']" % (S(a),S(b)) for a,b in chains) + ",")
        out.append("    ]);")
        if sub in ('cs', 'major') and coding_grade:
            out.append("    await this._trainCodingStories('%s', ctx, { reps: 4, ticksPerWord: 2 });" % coding_grade)
        out.append("    await this._teachProductionStack('%s', ctx, { tag: '%s' });" % (sub, tag))
        out.append("    return await this._gateSubjectProduction('%s', '%s', [" % (sub, GRADE))
        for q, e in samples:
            out.append("      { question: '%s', expected: [%s] }," % (S(q), ", ".join("'%s'" % S(x) for x in e)))
        out += ["    ], { gateSubjectTag: '%s' });" % gst, "  },", ""]
    src = src.replace(anchor, L(out) + nl + anchor, 1)
    io.open(p, "w", encoding="utf-8", newline="").write(src)
    print("OK %s: %d runners, nl=%r" % (GRADE, len(SPEC), nl))
