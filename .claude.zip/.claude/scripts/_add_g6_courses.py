import io
p = "js/brain/curriculum/grade6.js"
src = io.open(p, "r", encoding="utf-8", newline="").read()
crlf = src.count("\r\n"); lf = src.count("\n") - crlf
nl = "\r\n" if crlf >= lf else "\n"
def L(lines): return nl.join(lines)

anchor = "  async runLifeG6(ctx) {"
assert src.count(anchor) == 1

def runner(name, subject, tag, gst, vocab, sentences, chains, samples, extra=None):
    out = ["  async %s(ctx) {" % name, "    const VOCAB = ["]
    for i in range(0, len(vocab), 8):
        out.append("      " + ", ".join("'%s'" % w for w in vocab[i:i+8]) + ",")
    out.append("    ];")
    out.append("    await this._teachVocabList(VOCAB, ctx, { reps: 3 });")
    out.append("    const SENTENCES = [")
    for s in sentences:
        out.append("      '%s'," % s)
    out.append("    ];")
    out.append("    await this._teachSentenceList(SENTENCES, ctx, { reps: 2, ticksPerWord: 2 });")
    out.append("    await this._teachCausalChains([")
    out.append("      " + ", ".join("['%s', '%s']" % (a,b) for a,b in chains) + ",")
    out.append("    ]);")
    if extra:
        for ln in extra:
            out.append("    " + ln)
    out.append("    await this._teachProductionStack('%s', ctx, { tag: '%s' });" % (subject, tag))
    out.append("    return await this._gateSubjectProduction('%s', 'grade6', [" % subject)
    for q, e in samples:
        out.append("      { question: '%s', expected: [%s] }," % (q, ", ".join("'%s'" % x for x in e)))
    out.append("    ], { gateSubjectTag: '%s' });" % gst)
    out.append("  },")
    out.append("")
    return out

blocks = ["  // ── FULL-ROSTER G6 COURSES: Band&Choir / PE / Health / Spanish + real",
          "  // Computer Science (HTML/CSS/JS + trains the coding corpus — the self-taught",
          "  // hobby erupts via grandpa's computer). Course-identity prepended by the",
          "  // _cellRunner wrapper; each self-gates."]

blocks += runner("runMusicG6Real","music","MUSIC-G6","music",
  ['band','choir','ensemble','instrument','voice','soprano','alto','tenor','bass','section','blend','breath','support','sight','read','rehearsal','conductor','genre','baroque','classical','jazz','dynamics','phrase','tone'],
  ['band and choir are ensembles where many parts make one sound',
   'in choir the voices are soprano alto tenor and bass from high to low',
   'singers use breath support from the belly to hold long notes',
   'blend means no single voice sticks out above the group',
   'sight reading is playing or singing music you have never seen before',
   'the conductor keeps the whole ensemble together with a beat',
   'each section plays its own part that fits the others',
   'rehearsal is where the group practices to become one sound',
   'music genres include baroque classical jazz and rock',
   'tone is the quality and color of a sound',
   'a phrase in music is shaped like a spoken sentence',
   'dynamics from pianissimo to fortissimo shape the feeling',
   'minor keys and slow tempos are why some music sounds dark',
   'good rehearsal etiquette means listening and staying quiet when others play',
   'a soloist steps out and the ensemble supports them',
   'we tune our instruments to the same pitch before we play'],
  [['choir','voices'],['breath','support'],['conductor','together'],['minor','dark'],['rehearsal','practice'],['blend','group'],['tone','quality']],
  [("a group where many parts make one sound is an", ["ensemble","e"]),
   ("the highest voice part in choir is", ["soprano","s"]),
   ("the lowest voice part is", ["bass","b"]),
   ("reading music you have never seen is sight", ["reading","read","r"]),
   ("singers hold long notes using breath", ["support","s"]),
   ("the person who keeps the ensemble together is the", ["conductor","c"]),
   ("when no single voice sticks out it is good", ["blend","b"]),
   ("the quality and color of a sound is its", ["tone","t"])])

blocks += runner("runPeG6Real","pe","PE-G6","pe",
  ['volleyball','basketball','soccer','serve','set','spike','dribble','shoot','pass','defense','offense','pacer','mile','endurance','goal','locker','team','rule','referee','strategy','position','fitness','assess','active'],
  ['middle school pe runs units in volleyball basketball and soccer',
   'in volleyball you bump set and spike the ball over the net',
   'in basketball you dribble pass and shoot to score',
   'in soccer you dribble with your feet and shoot on goal',
   'the pacer and the mile run test cardio endurance',
   'we set personal fitness goals and measure our progress',
   'each sport has positions with different jobs on the team',
   'a referee enforces the rules to keep the game fair',
   'a team uses strategy to create scoring chances',
   'good defense takes away the other teams space and time',
   'we changed in the locker room which felt awkward at first',
   'warming up and cooling down protects the body',
   'sportsmanship means respect even when we lose',
   'staying active in middle school builds lifelong habits',
   'we assess our own fitness honestly to improve it',
   'practicing a skill the right way slowly builds it correctly'],
  [['serve','volleyball'],['dribble','basketball'],['pacer','endurance'],['referee','fair'],['defense','space'],['warm','protect'],['active','habit']],
  [("in volleyball you bump set and", ["spike","s"]),
   ("in basketball you dribble pass and", ["shoot","s"]),
   ("the run that tests cardio endurance is the", ["mile","pacer","m","p"]),
   ("the person who enforces the rules is the", ["referee","r"]),
   ("a team plan to create scoring chances is", ["strategy","s"]),
   ("good defense takes away the other team's", ["space","time","s","t"]),
   ("respect even when we lose is", ["sportsmanship","sport","s"]),
   ("we set personal fitness", ["goals","goal","g"])])

blocks += runner("runHealthG6Real","health","HEALTH-G6","health",
  ['health','puberty','hormone','menstruation','period','development','nutrition','calorie','macro','protein','anxiety','depression','image','esteem','vaping','nicotine','alcohol','marijuana','boundary','consent','healthy','relationship','online','refuse','stress'],
  ['puberty brings major body changes driven by hormones',
   'menstruation is the monthly cycle a girls body goes through and it is normal',
   'everyone develops at their own pace and comparison is not useful',
   'nutrition balances calories from protein carbohydrate and fat',
   'anxiety and depression are real health conditions not weakness',
   'body image is how we see our own body and media can distort it',
   'self esteem can be protected by focusing on what our body can do',
   'vaping puts nicotine and chemicals into the lungs and is addictive',
   'alcohol and marijuana affect the growing brain more than an adult brain',
   'a personal boundary is a limit we set on how others treat us',
   'consent means a clear yes and anyone can say no at any time',
   'a healthy relationship has respect trust and honesty',
   'an unhealthy relationship has control pressure and disrespect',
   'we can refuse peer pressure and keep our own values',
   'managing stress with sleep exercise and talking keeps us well',
   'we protect ourselves online by guarding private information'],
  [['puberty','hormone'],['menstruation','normal'],['vaping','nicotine'],['anxiety','real'],['boundary','limit'],['consent','yes'],['healthy','respect']],
  [("the monthly cycle a girls body goes through is", ["menstruation","period","m","p"]),
   ("body changes in puberty are driven by", ["hormones","hormone","h"]),
   ("vaping puts what addictive chemical in the lungs", ["nicotine","n"]),
   ("a clear yes that anyone can withdraw is", ["consent","c"]),
   ("a limit we set on how others treat us is a", ["boundary","b"]),
   ("a healthy relationship is built on respect trust and", ["honesty","honest","h"]),
   ("anxiety and depression are real health", ["conditions","condition","c"]),
   ("how we see our own body is body", ["image","i"])])

blocks += runner("runLanguageG6Real","language","SPANISH-G6","language",
  ['spanish','verbo','presente','pasado','hable','comi','ayer','hoy','manana','familia','madre','padre','hermana','ciudad','pais','mucho','poco','tambien','pero','porque','frase','cultura','fiesta'],
  ['in spanish the present tense tells what happens now',
   'the past tense tells what already happened',
   'yo hablo means i speak and yo hable means i spoke',
   'yo como means i eat and yo comi means i ate',
   'ayer means yesterday hoy means today manana means tomorrow',
   'la familia includes la madre el padre and la hermana',
   'la ciudad is the city and el pais is the country',
   'mucho means a lot and poco means a little',
   'tambien means also and pero means but',
   'we can build longer sentences by joining ideas with pero and porque',
   'a frase is a phrase or sentence',
   'spanish speaking countries have rich cultures and fiestas',
   'we read a short paragraph in spanish and find the main idea',
   'cognates help us guess new words from english',
   'practicing conversation out loud is how fluency grows',
   'learning the culture makes the language come alive'],
  [['presente','now'],['pasado','before'],['ayer','yesterday'],['familia','family'],['ciudad','city'],['pero','but'],['porque','because']],
  [("the tense that tells what happens now is", ["presente","present","p"]),
   ("the tense that tells what already happened is", ["pasado","past","p"]),
   ("ayer means", ["yesterday","y"]),
   ("manana means", ["tomorrow","t"]),
   ("la ciudad is the", ["city","c"]),
   ("pero means", ["but","b"]),
   ("a lot in spanish is", ["mucho","m"]),
   ("joining ideas with because uses", ["porque","p"])])

blocks += runner("runCsG6Real","cs","CS-G6","cs",
  ['html','css','javascript','tag','element','attribute','browser','webpage','heading','paragraph','link','image','style','selector','property','color','font','variable','function','console','script','document','editor','save'],
  ['html is the language that gives a webpage its structure',
   'css is the language that styles how a webpage looks',
   'javascript is the language that makes a webpage interactive',
   'an html tag is written inside angle brackets like a paragraph tag',
   'most elements have an opening tag and a closing tag',
   'an attribute gives extra information inside a tag like the source of an image',
   'a heading tag makes big bold title text',
   'a paragraph tag holds a block of text',
   'a link tag connects one page to another',
   'an image tag shows a picture from a file',
   'a css selector chooses which elements to style',
   'a css property like color sets one part of the style',
   'in javascript a variable stores a value with a name',
   'in javascript a function is reusable code we can call by name',
   'the browser reads the html css and javascript and draws the page',
   'we write code in an editor and save the file and open it in the browser',
   'the console shows messages and errors from our javascript',
   'i taught myself to build a real webpage from nothing but code'],
  [['html','structure'],['css','style'],['javascript','interactive'],['tag','element'],['selector','style'],['variable','value'],['function','reuse'],['browser','page']],
  [("the language that structures a webpage is", ["html","h"]),
   ("the language that styles a webpage is", ["css","c"]),
   ("the language that makes a page interactive is", ["javascript","j"]),
   ("a piece of html in angle brackets is a", ["tag","t"]),
   ("what chooses which elements css styles is a", ["selector","s"]),
   ("a named store for a value in javascript is a", ["variable","v"]),
   ("reusable code we call by name is a", ["function","f"]),
   ("the program that draws the webpage is the", ["browser","b"])],
  extra=["// the self-taught hobby: train the REAL coding corpus (corpora/coding/grade6.json)",
         "await this._trainCodingStories('grade6', ctx, { reps: 4, ticksPerWord: 2 });"])

block_text = L(blocks) + nl
src = src.replace(anchor, block_text + anchor, 1)
io.open(p, "w", encoding="utf-8", newline="").write(src)
print("OK grade6.js: 5 new-track runners (incl real-CS + coding corpus) added. nl=", repr(nl))
